#include<stdio.h>
int main()
{
int i, j, n;
printf("\nEnter the highest range : ");
scanf("%d", &n);
printf("Series of prime number upto %d is : \n", n);
for(i=2; i<=n; i++)
{
    for (j=2; j<=i; j++)
    {
        if(i%j==0)
        break;
    }
    if(i==j)
        printf("%d ", i);
}
return 0;
}
