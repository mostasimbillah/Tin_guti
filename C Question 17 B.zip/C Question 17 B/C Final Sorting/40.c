#include<stdio.h>
int main()
{
    int a[5][5];
    int
    i,j;
    for(i=0;i<5;i++)
    {
        for(j=0;j<5;j++)
        {
            scanf("%d",&a[i][j]);
        }

    }
    for(i=0;i<5;i++)
    {
        for(j=0;j<5;j++)
        {
            printf("%d ",a[i][j]);
        }
        printf("\n");

    }
  // printf("%d",a[1][2]);

return 0;
}
