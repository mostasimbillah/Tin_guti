#include<stdio.h>
int main()
{
    int a, b;
    for(b=0; b<=3; b++)
    {
        for(a=0; a<=b; a++)
        {
            printf("*");
        }
        printf("\n");
    }
    for(a=5; a>=1; a--)
    {
        for(b=1; b<=a; b++)
        {
            printf("*");
        }
        printf("\n");
    }
    for(b=0; b<=3; b++)
    {
        for(a=0; a<=b; a++)
        {
            printf("*");
        }
        printf("\n");
    }

    for(a=5; a>=1; a--)
    {
        for(b=1; b<=a; b++)
        {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}

