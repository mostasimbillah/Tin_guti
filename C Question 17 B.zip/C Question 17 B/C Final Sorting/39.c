#include<stdio.h>
int main()
{
    int a,b,op;
    printf("enter your first value:\n");
    scanf("%d",&a);
    printf("enter your second value:\n");
    scanf("%d",&b);
    printf("enter your operator:\n1 for plus, 2for minus, 3for multiple, 4 for divide\n");
    scanf("%d",&op);

    if(op==1)
        printf("Your Result Is:%d",a+b);
    else if(op==2)
        printf("Your Result Is:%d",a-b);
    else if(op==3)
        printf("Your Result Is:%d",a*b);
    else if(op==4)
        printf("Your Result Is:%d",a/b);
    else
        printf("wrong operator");
    return 0;
}
