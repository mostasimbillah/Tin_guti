#include<stdio.h>
void RectangleArea()
{
    float Length,Width,Rectangle_Area;
    printf("Enter the value of length & Width:");
    scanf("%f%f",&Length,&Width);
    Rectangle_Area=Length*Width;
    printf("The Area of Rectangle is=%.2f",Rectangle_Area);
}
void main()
{

    RectangleArea();
}
