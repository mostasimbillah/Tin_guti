#include<stdio.h>
int main()
{
    int i,x=4;
    int prime=1;
    if (i==1)
    {
        prime=0;
    }
    else if (i==2)
    {
        prime=1;
    }
    else
    {
        for (i=2;i<x;i++)
        {
            if (x%i==0)
                prime=0;
        }
        if(prime==1)
            printf ("yes");
        else
            printf ("no");
    }
}
