#include <stdio.h>
int main()
{
    int a,b,j;
    while(1)
    {
        printf("Enter two number you want to sum\n");
        scanf("%d%d",&a,&b);
        j=a+b;
        printf("result is %d\n\n",j);
    }
    return 0;
}
