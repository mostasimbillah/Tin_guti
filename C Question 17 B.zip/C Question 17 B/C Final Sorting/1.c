#include<stdio.h>

int main()
{
    int a = 1;
    int b = 2;
    int c = a + b;
    printf("Sum of a and b = %d\n", c);
    return 0;
}
