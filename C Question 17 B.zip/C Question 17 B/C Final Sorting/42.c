#include <stdio.h>
int main()
{
    int x;
    int arr[11]={3,5,7,9,11};
    printf("the outputs are : \n");
    for(x=0;x<11;x++)
    {
        printf("%d",arr[x]);
    }
    return 0;
}
