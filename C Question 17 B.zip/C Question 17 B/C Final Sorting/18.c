#include<stdio.h>
void main()
{
    int mark;
    printf("enter the mark: ");
    scanf("%d",&mark);
    if(mark>=33)
        printf("pass ");
    else
        printf("fail ");
    getch();

}
