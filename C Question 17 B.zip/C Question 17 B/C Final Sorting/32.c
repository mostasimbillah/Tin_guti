#include<stdio.h>
int main()
{
    char name[30];
    scanf("%s",&name);
    printf("Welcome %s !");
    return 0;
}
