#include<stdio.h>
float max(float a[])
{
    int i;
    float mx=0;
    for(i=0;i<5;i++)
    {
        if(a[i]>mx)
        {
            mx=a[i];
        }
    }
    return mx;
}
int main()
{
    int n=5,i,j;
    float m,f,e,b,avg;
    float a[5];
    for(i=0;i<n;i++)
    {
        printf("\nEnter %dth students data: \n",i+1);
        printf("Enter GPA of Math: ");
        scanf("%f",&m);
        printf("Enter GPA of English: ");
        scanf("%f",&e);
        printf("Enter GPA of Bangla: ");
        scanf("%f",&b);
        avg=(m+e+b)/3;
        printf("%f",avg);
        a[i]=avg;
    }
    f=max(a);
    printf("\n%.2f",f);
    return 0;
}
