#include<stdio.h>
void main()
{
    int a,b,c,max;
    printf("first number a: ");
    scanf("%d",&a);
    printf("second number b: ");
    scanf("%d",&b);
    printf("third number c: ");
    scanf("%d",&c);
    if(a>b)
    {
        if(a>c)
            max=a;
        else
            max=c;
    }
    else
    {
        if(b>c)
            max=b;
        else
            max=c;
    }
    printf("maximum number =%d",max);
    getch();
}
