#include<stdio.h>
int main()
{
    int first=0,second=1,k,fibo;
    printf("%d\n%d\n",first,second);
    for(k=0;k<=25;k++)
    {
        fibo=first+second;
        printf("%d\n",fibo);
        first=second;
        second=fibo;
    }
    return 0;
}
