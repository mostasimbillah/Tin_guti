#include<stdio.h>
int main()
{
    int i,j;
    for(i=1;i<=9;i=i+2)
    {
        for(j=9;j>=i;j=j--)
        {
            if(j%2==1)
                printf("%d",j);
        }
        printf("\n");
    }
}
