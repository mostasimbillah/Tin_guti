#include<stdio.h>
int main()
{
    int i, n;
    long sum=0;
    printf("\nEnter a positive integer :");
    scanf("%d", &n);
    printf("\nSUM OF SERIES");
    printf("\n--------------");
    printf("\n1 + 2 + 3+ ... + %d = ", n);
    for (i=1; i<=n; i=i+1)
    {
        sum=sum+i;
    }
    printf("%ld", sum);
    return 0;
}
