#include <stdio.h>
int main()
{
    int x,y,z;
    printf("Enter Number :  ");
    scanf("%d",&x);
    for(y=0; y<x; y++)
    {
        printf("%d ",y);
    }
    if(y%2==0)
    {
        printf("\nEven");
    }
    else
    {
        printf("\nOdd");
    }
return 0;

}

