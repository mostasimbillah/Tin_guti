#include <stdio.h>
int main()
{
    int i,j;
    for(i=0;i<3;i++)
    {
        printf("Enter the amount of money\n");
        scanf("%d",&j);
        if(j<=500)
            printf("You are in budget,please take it\n\n");
        else
            printf("Out of budget,can't buy\n\n");
    }
    return 0;
}
