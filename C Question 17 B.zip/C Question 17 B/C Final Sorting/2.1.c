#include<stdio.h>
int main()
{
    int mark;
    scanf("%d",&mark);
    if(mark<40)
    {
        printf("Fail");
    }
    else if(mark>=40 && mark<60)
    {
        printf("B");
    }
    else if(mark>=60 && mark<80)
    {
        printf("A");
    }
    else
    {
        printf("A+");
    }

}
