#include<stdio.h>
float getArea(float a, float b);
int main()
{
    float l,i;
    scanf("%f%f",&l,&i);

    printf("Area:%.2f",getArea(l,i));
    return 0;
}
float getArea(float a, float b)
{
    return a*b;
}
