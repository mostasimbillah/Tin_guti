#include<stdio.h>
int area(int x,int y);
int main()
{
    int b,h,a;
    scanf("%d%d",&b,&h);
    a=area(b,h);
    printf("Area of triangle is:%d",a);
    return 0;
}
int area(int x,int y)
{
    int area=(x*y)*.5;
    return area;
}
