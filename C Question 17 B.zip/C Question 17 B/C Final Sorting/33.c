#include<stdio.h>
int main()
{
    char a;
    printf("Enter your character\n");
    scanf("%c",&a);
    printf("Ascii value of your character is : %d",a);
    return 0;
}
