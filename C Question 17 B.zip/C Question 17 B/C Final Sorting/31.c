#include<stdio.h>
int main()
{
    int arr[5]={5,90,-6,-7,77};
    int i,a,j;
    for(i=0;i<5;i++)
    {
        for(j=i+1;j<5;++j)
        {
            if(arr[i]>arr[j])
            {
                a=arr[i];
                arr[i]=arr[j];
                arr[j]=a;
            }
        }
    }
    printf("Second lowest: %d",arr[1]);
}
