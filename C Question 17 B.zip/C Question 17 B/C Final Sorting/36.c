#include <stdio.h>
float getavg (float x, float y,float z)
{
    float avg= (x+y+z)/3; return avg;
}
int main ()
{
    float x=getavg (10, 20, 30);
    printf ("%.2f", x);
    return 0;
}
