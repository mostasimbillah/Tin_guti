#include <stdio.h>
int main()
{
    int row, line, star;
    printf("Enter the number of rows: ");
    scanf("%d",&row);
    for(line=0; line<row; line++)
    {
        for(star=0;star<=line;star++)
        {
            printf("*");
        }
        printf("\n");
    }
return 0;
}
