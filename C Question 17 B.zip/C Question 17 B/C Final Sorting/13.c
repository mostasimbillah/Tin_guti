#include<stdio.h>
int main()
{
    int c;
    printf("Enter 1 to display characters in uppercase and 2 to display in lowercase: \n");
    scanf("%d",&c);
    if(c==1)
    {
        for(c='A'; c<='Z'; ++c)
        {
            printf("%c ",c);
        }
    }
    else if (c==2)
    {
        for(c='a'; c<='z'; ++c)
        {
            printf("%c ",c);
        }
    }
    else
        printf("Wrong !!!");

return 0;
}
