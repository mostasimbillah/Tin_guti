#include<stdio.h>
int main()
{
    int a,i,sum=0;
    printf("Enter your numbers: ");
    for(i=0;i<=6;i++)
    {
        scanf("%d",&a);
        if(a%2==0)
        {
            sum=sum+a;
        }
    }
    printf("Your result is: %d",sum);
}
