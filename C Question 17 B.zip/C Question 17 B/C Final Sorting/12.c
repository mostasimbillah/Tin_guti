#include <stdio.h>
int main ()
{
    int i,j,k;
    i=6;
    for (j=1;j<=i;j++)
    {
        for(k=1;k<=j;k++)
        {
            printf ("%d ",j*k);
        }
        printf("\n");
    }
    return 0;

}

