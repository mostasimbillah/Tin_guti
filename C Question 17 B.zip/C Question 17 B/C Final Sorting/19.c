#include <stdio.h>
int main()
{
    int a;
    for(a=100; a<=500; a++)
    {
        if(a%2==1)
        printf("%d\n", a);
    }
    return 0;
}
