#include<stdio.h>
void main()
{
    long int n;
    int i=1, d=0;
    xx:
    printf("\nEnter a positive interger :");
    scanf("%ld", &n);
    if (n<=0)
    goto xx;

    printf("Divisors of %ld are : ", n);
    while(i<=n)
    {
        if(n%i==0)
        {
            printf("%4d", i);
            d++;
        }
    i++;
    }
    printf("\nNumber of totel divisors is %d", d);
}
